# AI collaboration

## Data analysis

- **Timezone:** `CAL-A4` is the only UTC timestamp. 19:00Z is 15:00 EDT (DST began 9 Mar 2025), while CRM says 14:00, so this is a real conflict.
- **Duplicate vs. recurrence:** `CAL-A5`/`CAL-A6` are the same Pinnacle meeting. `CAL-A3`/`CAL-A18` are a weekly series, not duplicates.
- **Conflicts:**
  - location/format: `CRM-1002`
  - status: `CRM-1009` (cancelled)
  - time: `CRM-1004`, `CRM-1016`
- **Malformed data:**
  - the date `"03-15/2025"`
  - a missing time
  - the email `raj.patel[at]...`
  - the attendee `"external-guests"`
  - the placeholder client `"Multiple"`